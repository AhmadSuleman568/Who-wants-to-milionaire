package com.tilloop1.whowantstobemillionaire;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity3 extends AppCompatActivity {

    RadioGroup rgOptions;
    Button btnSubmit;
    TextView tvQuestion, tvAmount;
    RadioButton rb1, rb2, rb3, rb4;
    String selectedSuperStar , answer_text="Peace of Activity";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main3);
        getSupportActionBar().hide();

        // Get views from the layout and initialize to be used later
        btnSubmit = (Button) findViewById(R.id.btnSubmit);
        tvQuestion = (TextView) findViewById(R.id.tvQuestion);
        rgOptions = (RadioGroup) findViewById(R.id.rgOptions);
        rb1 = (RadioButton) findViewById(R.id.rbOption1);
        rb2 = (RadioButton) findViewById(R.id.rbOption2);
        rb3 = (RadioButton) findViewById(R.id.rbOption3);
        rb4 = (RadioButton) findViewById(R.id.rbOption4);
        tvAmount = (TextView) findViewById(R.id.tvAmt);
    }

    public void Submit(View view) {
        if (rb1.isChecked()) {
            selectedSuperStar = rb1.getText().toString();
        } else if (rb2.isChecked()) {
            selectedSuperStar = rb2.getText().toString();
        } else if (rb3.isChecked()) {
            selectedSuperStar = rb3.getText().toString();
        } else if (rb4.isChecked()) {
            selectedSuperStar = rb4.getText().toString();
        }

        if(selectedSuperStar != null){

            //Check if the user selection is equal to the answer
            if(selectedSuperStar.equals(answer_text)) {
                // Correct answer
                Toast toast = Toast.makeText(getApplicationContext(), getString(R.string.toast_correct) + "12,500$", Toast.LENGTH_SHORT);
                toast.show();
                Intent intent=new Intent(this,MainActivity4.class);
                startActivity(intent);

            }
            else{
                Toast toast = Toast.makeText(getApplicationContext(), "Sorry! You lost the game", Toast.LENGTH_SHORT);
                toast.show();
                Intent intent=new Intent(this,HomeActivity.class);
                startActivity(intent);
                finish();
            }
        }
    }
}