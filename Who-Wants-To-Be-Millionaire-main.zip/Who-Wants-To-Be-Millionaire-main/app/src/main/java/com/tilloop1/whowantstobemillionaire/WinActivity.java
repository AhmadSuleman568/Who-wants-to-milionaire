package com.tilloop1.whowantstobemillionaire;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.view.animation.LinearInterpolator;
import android.widget.ImageView;
import android.widget.TextView;
public class WinActivity extends AppCompatActivity {

    // Class members
    ImageView center_image;
    Animation expand, slide;
    TextView tvAmt, tvCongrats;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_win);
        getSupportActionBar().hide();

        // Get the TextView view for the amount to be shown on the screen
        tvAmt = (TextView) findViewById(R.id.tvAmt);


            // Bundle contains something!
            String msg = "1,000,000$";
            msg = "You won $" + msg;
            // Update message on the TextView
            tvAmt.setText(msg);
        }

}
